<?php
    // default page script
    echo "COMPGC06 Databases Project";
    echo "<br>";
    echo "Group 30";
    echo "<br>";
    echo "Default PHP Page";
?>

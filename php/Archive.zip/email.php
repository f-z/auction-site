<!doctype html>
<html>
  <head>
    <meta name="viewport" content="width=device-width" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body class="">
  <table border="0" cellpadding="0" cellspacing="0" class="body">
    <tr>
      <td>&nbsp;</td>
      <td class="container">
        <div class="content">

          <table class="main">
            <tr>
              <td class="wrapper">
                <table border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td>
                      <p>Hi <?php $firstname?>,</p>
                      <p>You are currently the highest bidder (<?php echo $time ?>)!.</p>
                      <p>Looking good so far. It's almost yours, but you could still be outbid. You can improve your chances by increasing your max bid.</p>
                      <table border="0" cellpadding="0" cellspacing="0">
                        <tbody>
                          <tr>
                            <td align="left">
                              <table border="0" cellpadding="0" cellspacing="0">
                                <tbody>
                                  <tr>
                                    <td> <a href="http://htmlemail.io" target="_blank">Call To Action</a> </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>

          <div class="footer">
            <table border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td class="content-block">
                  <span>
                      <b>UCLBay</b>
                      <br>
                      Gower Street
                      <br>
                      London
                      <br>
                      WC1B 6BE</span>
                </td>
              </tr>
              </tr>
            </table>
          </div>

        </div>
      </td>
      <td>&nbsp;</td>
    </tr>
  </table>
</body>
</html>